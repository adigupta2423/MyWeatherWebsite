let songs = [
  {
    name: "Ram Siya Ram",
    artist: "jubin",
    img: "img1",
    audio: "music1"
  },
  {
    name: "Dil-Ibbadt",
    artist: "KK",
    img: "img2",
    audio: "music2"
  },
  {
    name: "Born to shine",
    artist: "Diljit",
    img: "img3",
    audio: "music3"
  },
  {
    name: "Hass-Hass",
    artist: "Diljit",
    img: "img4",
    audio: "music4"
  }
]